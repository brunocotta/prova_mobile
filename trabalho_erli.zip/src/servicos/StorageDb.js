import * as SQLite from "expo-sqlite"

const db = SQLite.openDatabase("albums.db");

export function criaTabela() {
    db.transaction((transaction) => {
        transaction.executeSql("CREATE TABLE IF NOT EXISTS Albums (id INTEGER PRIMARY KEY AUTOINCREMENT, urlImg TEXT, nomeAlbum TEXT, ano TEXT);");
        transaction.executeSql("CREATE TABLE IF NOT EXISTS Musicas (id INTEGER PRIMARY KEY AUTOINCREMENT, albumId INTEGER, nomeMusica TEXT);");
    })
}
export async function addMusica(musica) {
    return new Promise((resolve) => {
        db.transaction((transaction) => {
            transaction.executeSql("INSERT INTO Musicas (albumId, nomeMusica) VALUES (?, ?);", [musica.albumId, musica.nomeMusica],() => {
                resolve("Musica adicionado com sucesso!");
            })
        })
    })
}
export async function todasMusicasDoAlbum(albumId) {
    return new Promise((resolve) => {
        db.transaction((transaction) => {
            transaction.executeSql("SELECT * FROM Musicas WHERE albumId = ?;", [albumId],(transaction, resultado) => {
                resolve(resultado.rows._array);
            })
        })
    })
}

export async function deletaMusica(musica) {
    return new Promise((resolve) => {
        db.transaction((transaction) => {
            transaction.executeSql("DELETE FROM Musicas WHERE id=?;", [musica.id],() => {
                resolve("Musica removido com sucesso!");
            })
        })
    })
}

export async function addAlbum(album) {
    return new Promise((resolve) => {
        db.transaction((transaction) => {
            transaction.executeSql("INSERT INTO Albums (urlImg, nomeAlbum, ano) VALUES (?, ?, ?);", [album.urlImg, album.nomeAlbum, album.ano],() => {
                resolve("Album adicionado com sucesso!");
            })
        })
    })
}

export async function deletaAlbum(album) {
    return new Promise((resolve) => {
        db.transaction((transaction) => {
            transaction.executeSql("DELETE FROM Albums WHERE id=?;", [album.id],() => {
                resolve("Album removido com sucesso!");
            })
        })
    })
}

export async function todosAlbums() {
    return new Promise((resolve) => {
        db.transaction((transaction) => {
            transaction.executeSql("SELECT * FROM Albums;", [],(transaction, resultado) => {
                resolve(resultado.rows._array);
            })
        })
    })
}

export async function getAlbumById(id) {
    return new Promise((resolve) => {
        db.transaction((transaction) => {
            transaction.executeSql("SELECT * FROM Albums WHERE id = " + id + ";", [],(transaction, resultado) => {
                resolve(resultado.rows.item(0));
            })
        })
    })
}

export async function atualizarAlbum(album) {
    return new Promise((resolve) => {
        db.transaction((transaction) => {
            transaction.executeSql("UPDATE Albums SET urlImg = ?, nomeAlbum = ?, ano = ? WHERE id = ?;", [album.urlImg, album.nomeAlbum, album.ano, album.id],() => {
                resolve("Album atualizado com sucesso!");
            })
        })
    })
}
