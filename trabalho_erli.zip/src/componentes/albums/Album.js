import React from "react";
import { Image, TouchableOpacity, View, Text, StyleSheet } from "react-native";
import { deletaAlbum, todosAlbums } from "../../servicos/StorageDb";
import { useNavigation } from "@react-navigation/native";

export default function Album({item, setAlbums}) {

    const navigation = useNavigation();

    async function atualizaAlbums() {
        const allAlbums = await todosAlbums();
        setAlbums(allAlbums);
    }

    async function excluirAlbum() {
        await deletaAlbum(item)
        atualizaAlbums();
    }

    function abrirAlbum() {
        navigation.navigate('Album', {albumId: item.id});
    }
    

    return(
        <View style={estilos.card}>
            <TouchableOpacity style={estilos.infos1} onPress={abrirAlbum}>
                <View style={estilos.img}>
                    <Image source={{uri: item.urlImg}} style={estilos.imagem} />
                </View>
                <View style={estilos.infos}>
                    <Text>{item.nomeAlbum}</Text>
                    <Text>{item.ano}</Text>
                </View>
            </TouchableOpacity>
            <TouchableOpacity
                style={estilos.btnExcluir}
                onPress={excluirAlbum}
            >
                <Text style={estilos.textoExcluir}>Excluir</Text>
            </TouchableOpacity>
        </View>
    )
}

const estilos = StyleSheet.create({
    card: {
        width: "90%",
        height: 80,
        backgroundColor: "#E0E0E0",
        marginLeft: "5%",
        marginTop: 20,
        flexDirection: "row",
        borderRadius: 5,
        justifyContent: "space-between"
    },
    infos1: {
        borderWidth: 1,
        width: "80%",
        borderTopLeftRadius: 5,
        borderBottomLeftRadius: 5,
        flexDirection: "row"
    },
    img: {
        width: "40%"
    },
    imagem: {
        width: "100%",
        height: 78,
        borderTopLeftRadius: 5,
        borderBottomLeftRadius: 5,
    },
    infos: {
        width: "60%",
        justifyContent: "center",
        alignItems: "center"
    },
    btnExcluir: {
        width: "20%",
        backgroundColor: "#6f2323",
        justifyContent: "center",
        alignItems: "center",
        borderTopRightRadius: 5,
        borderBottomRightRadius: 5
    },
    textoExcluir: {
        color: "#fff"
    }
})
