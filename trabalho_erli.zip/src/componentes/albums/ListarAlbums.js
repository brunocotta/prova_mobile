import React, { forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { todosAlbums } from "../../servicos/StorageDb";
import { FlatList, Text, View } from "react-native";

import Album from "./Album";

const ListarAlbums = forwardRef((props, _ref) => {
    useEffect(() => {
        mostraAlbums();
    }, [albums])

    const [albums, setAlbums] = useState([]);

    async function mostraAlbums() {
        const allAlbums = await todosAlbums();
        setAlbums(allAlbums);
    }

    useImperativeHandle(_ref, () => ({
        atualizarAlbums: () => {
            mostraAlbums();
        }
    }))

    return <View>
        <Text>Lista de Albums</Text>
        <FlatList
            scrollEnabled={false}
            data={albums}
            renderItem={(album) => <Album {...album} setAlbums={setAlbums} />}
            keyExtractor={album => album.id}
        />
    </View>
});

export default React.memo(ListarAlbums);
