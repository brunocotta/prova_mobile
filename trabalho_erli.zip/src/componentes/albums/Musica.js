import React from "react";
import { TouchableOpacity, View, Text, StyleSheet } from "react-native";
import { deletaMusica, todasMusicasDoAlbum } from "../../servicos/StorageDb";

export default function Musica({ item, setMusicas }) {
    async function atualizaMusicas() {
        const allMusicas = await todasMusicasDoAlbum(item.albumId);
        setMusicas(allMusicas);
    }

    async function excluirMusica() {
        await deletaMusica(item);
        await atualizaMusicas();
    }
    

    return (
        <View style={estilos.card}>
            <Text>{item.nomeMusica}</Text>
            <TouchableOpacity
                style={estilos.btnExcluir}
                onPress={excluirMusica}
            >
                <Text style={estilos.textoExcluir}>Excluir</Text>
            </TouchableOpacity>
        </View>
    )
}

const estilos = StyleSheet.create({
    card: {
        width: "90%",
        height: 80,
        backgroundColor: "#E0E0E0",
        marginLeft: "5%",
        marginTop: 20,
        flexDirection: "row",
        borderRadius: 5,
        justifyContent: "space-between"
    },
    btnExcluir: {
        width: "20%",
        backgroundColor: "#6f2323",
        justifyContent: "center",
        alignItems: "center",
        borderTopRightRadius: 5,
        borderBottomRightRadius: 5
    },
    textoExcluir: {
        color: "#fff"
    }
})
