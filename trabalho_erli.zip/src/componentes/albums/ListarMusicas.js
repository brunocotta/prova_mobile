import React, { forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { todasMusicasDoAlbum } from "../../servicos/StorageDb";
import { FlatList, Text, View } from "react-native";

import Musica from "./Musica";

const ListarMusicas = forwardRef((props, _ref) => {
    useEffect(() => {
        mostraMusicas();
    }, [musicas])

    const [musicas, setMusicas] = useState([]);

    async function mostraMusicas() {
        const allMusicas = await todasMusicasDoAlbum(props.albumId);
        setMusicas(allMusicas);
    }

    useImperativeHandle(_ref, () => ({
        atualizarMusicas: () => {
            mostraMusicas();
        }
    }))

    return <View>
        <Text>Lista de Musicas</Text>
        <FlatList
            scrollEnabled={false}
            data={musicas}
            renderItem={(musica) => <Musica {...musica} setMusicas={setMusicas} />}
            keyExtractor={musica => musica.id}
        />
    </View>
});

export default React.memo(ListarMusicas);
