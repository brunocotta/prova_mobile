import React, { useEffect, useRef, useState } from "react";
import { addAlbum, criaTabela } from "../servicos/StorageDb";
import { ScrollView, StyleSheet, Text, TextInput, TouchableOpacity } from "react-native";
import ListarAlbums from "./albums/ListarAlbums";
import { useNavigation } from "@react-navigation/native";

export default function Inicio() {

    useEffect(() => {
        criaTabela();
    }, []);

    const navigation = useNavigation();

    useEffect(() => {
        const unsubscribe = navigation.addListener('focus', () => {
            listaAlbumRef.current.atualizarAlbums();
        });
        return unsubscribe;
    }, [navigation]);

    const [urlImg, setUrlImg] = useState("");
    const [nomeAlbum, setNomeAlbum] = useState("");
    const [ano, setAno] = useState("");
    const listaAlbumRef = useRef();

    async function cadastrarAlbum() {
        const album = {
            urlImg: urlImg,
            nomeAlbum: nomeAlbum,
            ano: ano
        }

        await addAlbum(album);
        listaAlbumRef.current.atualizarAlbums();
    }

    return <ScrollView style={estilos.inicio}>
        <Text style={estilos.boasVindas}>Bem vindo!</Text>
        <Text style={estilos.labelInput}>Insira o link de uma imagem para o album:</Text>
        <TextInput
            style={estilos.inputInicio}
            onChangeText={novaImagem => setUrlImg(novaImagem)}
            value={urlImg}
        />

        <Text style={estilos.labelInput}>Insira o nome do album:</Text>
        <TextInput
            style={estilos.inputInicio}
            onChangeText={novoAlbum => setNomeAlbum(novoAlbum)}
            value={nomeAlbum}
        />

        <Text style={estilos.labelInput}>Insira o ano do album:</Text>
        <TextInput
            style={estilos.inputInicio}
            keyboardType="numeric"
            onChangeText={novoAno => setAno(novoAno)}
            value={ano}
        />

        <TouchableOpacity
            style={estilos.btnCadastrar}
            onPress={cadastrarAlbum}
        >
            <Text style={estilos.txtCadastrar}>Cadastrar</Text>
        </TouchableOpacity>

        <ListarAlbums ref={listaAlbumRef} />

    </ScrollView>
}

const estilos = StyleSheet.create({
    inicio: {
        width: "100%",
        backgroundColor: "#aabbcc"
    },
    boasVindas: {
        marginTop: 50,
        textAlign: "center",
        fontSize: 24,
        marginBottom: 50
    },
    labelInput: {
        textAlign: "center",
        marginTop: 30
    },
    inputInicio: {
        width: "80%",
        height: 40,
        borderWidth: 1,
        borderColor: "#000",
        borderRadius: 5,
        marginTop: 10,
        marginLeft: "10%"
    },
    btnCadastrar: {
        width: "50%",
        height: 60,
        borderWidth: 1,
        borderColor: "#000",
        backgroundColor: "#3A606E",
        borderRadius: 5,
        marginTop: 20,
        marginLeft: "25%",
        marginBottom: 50,
        alignItems: "center",
        justifyContent: "center"
    },
    txtCadastrar: {
        color: "#fff",
        textAlign: "center"
    }
})
