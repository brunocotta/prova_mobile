import React, { useEffect,  useRef,  useState } from "react";
import { atualizarAlbum,  getAlbumById, addMusica } from "../servicos/StorageDb";
import { Alert, ScrollView, StyleSheet, Text, TextInput, TouchableOpacity } from "react-native";
import { useRoute } from "@react-navigation/native";
import ListarMusicas from "./albums/ListarMusicas";

export default function AlbumView() {
    const id = useRoute().params.albumId;

    useEffect(() => {
        (
            async () => {
                let album = await getAlbumById(id);
                setUrlImg(album.urlImg);
                setNomeAlbum(album.nomeAlbum);
                setAno(album.ano);
            }
        )();
    }, []);

    async function atualizar() {
        const album = {
            id: id,
            urlImg: urlImg,
            nomeAlbum: nomeAlbum,
            ano: ano
        }

        await atualizarAlbum(album);
        Alert.alert("Atualizado com sucesso.");
    }

    const listarMusicaRef = useRef();
    
    async function cadastrarMusica() {
        const musica = {
            albumId: id,
            nomeMusica,
        }

        await addMusica(musica);
        listarMusicaRef.current.atualizarMusicas();
    }

    const [urlImg, setUrlImg] = useState("");
    const [nomeAlbum, setNomeAlbum] = useState("");
    const [ano, setAno] = useState("");
    const [nomeMusica, setNomeMusica] = useState("");

    return <ScrollView style={estilos.inicio}>
        <Text style={estilos.labelInput}>Insira o link de uma imagem para o album:</Text>
        <TextInput
            style={estilos.inputInicio}
            onChangeText={novaImagem => setUrlImg(novaImagem)}
            value={urlImg}
        />

        <Text style={estilos.labelInput}>Insira o nome do album:</Text>
        <TextInput
            style={estilos.inputInicio}
            onChangeText={novoAlbum => setNomeAlbum(novoAlbum)}
            value={nomeAlbum}
        />

        <Text style={estilos.labelInput}>Insira o ano do album:</Text>
        <TextInput
            style={estilos.inputInicio}
            keyboardType="numeric"
            onChangeText={novoAno => setAno(novoAno)}
            value={ano}
        />

        <TouchableOpacity
            style={estilos.btnCadastrar}
            onPress={atualizar}
        >
            <Text style={estilos.txtCadastrar}>Atualizar</Text>
        </TouchableOpacity>

        <Text style={estilos.labelInput}>Insira o nome da musica:</Text>
        <TextInput
            style={estilos.inputInicio}
            onChangeText={nomeMusica => setNomeMusica(nomeMusica)}
            value={nomeMusica}
        />

        <TouchableOpacity
            style={estilos.btnCadastrar}
            onPress={cadastrarMusica}
        >
            <Text style={estilos.txtCadastrar}>cadastrarMusica</Text>
        </TouchableOpacity>
        
        <ListarMusicas ref={listarMusicaRef} albumId={id}/>
    </ScrollView>
}

const estilos = StyleSheet.create({
    imagem: {
        width: "100%",
        height: 78,
        borderTopLeftRadius: 5,
        borderBottomLeftRadius: 5,
    },
    inicio: {
        width: "100%",
        backgroundColor: "#aabbcc"
    },
    boasVindas: {
        marginTop: 50,
        textAlign: "center",
        fontSize: 24,
        marginBottom: 50
    },
    labelInput: {
        textAlign: "center",
        marginTop: 30
    },
    inputInicio: {
        width: "80%",
        height: 40,
        borderWidth: 1,
        borderColor: "#000",
        borderRadius: 5,
        marginTop: 10,
        marginLeft: "10%"
    },
    btnCadastrar: {
        width: "50%",
        height: 60,
        borderWidth: 1,
        borderColor: "#000",
        backgroundColor: "#3A606E",
        borderRadius: 5,
        marginTop: 20,
        marginLeft: "25%",
        marginBottom: 50,
        alignItems: "center",
        justifyContent: "center"
    },
    txtCadastrar: {
        color: "#fff",
        textAlign: "center"
    }
})
